const DEFAULT_TIMEOUT = 30;
const DEFAULT_AUTO_CLOSE_TIMEOUT = 300;
const DEFAULT_EXCLUDE_AUDIO = true;
const DEFAULT_WHITELIST = '';
const DEFAULT_KEEP_ACTIVE = 10;
const DEFAULT_LANGUAGE = 'auto';
// 由 i18n.js（经典脚本，先于本模块加载）挂载到 globalThis 的统一消息层
const i18n = globalThis.TabNapI18n;
let updateInterval;
let currentTabType = 'active'; // 'active' or 'napped'
let popupDisposed = false;

function stopPopupUpdates() {
  if (popupDisposed) return;
  popupDisposed = true;

  if (updateInterval) {
    clearInterval(updateInterval);
    updateInterval = undefined;
  }
}

function debugWarn(...args) {
  console.warn('[TabNap:popup]', ...args);
}

function isExpectedContextError(error) {
  const message = error?.message || '';
  return message.includes('Extension context invalidated')
    || message.includes('Extension context is invalid')
    || message.includes('context invalid');
}

function storageGet(defaults, label = 'storage.local.get') {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeoutId = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new Error(`${label} timed out`));
    }, 1500);

    try {
      chrome.storage.local.get(defaults, (items) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeoutId);

        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        resolve(items);
      });
    } catch (error) {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      reject(error);
    }
  });
}

function storageSet(items, label = 'storage.local.set') {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeoutId = setTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new Error(`${label} timed out`));
    }, 1500);

    try {
      chrome.storage.local.set(items, () => {
        if (settled) return;
        settled = true;
        clearTimeout(timeoutId);

        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        resolve();
      });
    } catch (error) {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      reject(error);
    }
  });
}

function translatePage() {
  // Translate text content
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const message = i18n.getMessage(key);
    if (message) {
      el.textContent = message;
    }
  });

  // Translate titles/tooltips
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const key = el.getAttribute('data-i18n-title');
    const message = i18n.getMessage(key);
    if (message) {
      el.dataset.tooltip = message;
      el.setAttribute('aria-label', message);
      el.removeAttribute('title');
    }

    el.onmouseenter = (e) => {
      const msg = el.dataset.tooltip || el.getAttribute('aria-label') || el.getAttribute('data-i18n-title') || '';
      if (msg) showTooltip(e, msg);
    };
    el.onmouseleave = hideTooltip;
    el.addEventListener('click', hideTooltip);
  });

  // Translate placeholders
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    const message = i18n.getMessage(key);
    if (message) {
      el.placeholder = message;
    }
  });
}

function showMainView() {
  document.getElementById('main-view').classList.remove('hidden');
  document.getElementById('settings-view').classList.add('hidden');
  updatePopup();
}

function showSettingsView() {
  document.getElementById('main-view').classList.add('hidden');
  document.getElementById('settings-view').classList.remove('hidden');
  restoreOptions();
  translatePage();
  setTimeout(postPopupSize, 0);
}

// 自动保存相关的防抖函数
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// 保存设置
function saveOptions(silent = false) {
  const timeoutInput = document.getElementById('timeout');
  const timeout = parseInt(timeoutInput.value, 10);
  const autoCloseTimeout = parseInt(document.getElementById('autoCloseTimeout').value, 10);
  const activeTabsToKeep = parseInt(document.getElementById('activeTabsToKeep').value, 10);
  const excludeAudio = document.getElementById('excludeAudio').checked;
  const enableAutoSleep = document.getElementById('enableAutoSleep').checked;
  const enableAutoClose = document.getElementById('enableAutoClose').checked;
  const enableKeepActive = document.getElementById('enableKeepActive').checked;
  const whitelist = document.getElementById('whitelist').value;
  const language = document.getElementById('language').value;

  // 在实时保存模式下，如果是无效数值，我们可以选择不保存或者恢复旧值，这里先保持逻辑
  if (enableAutoSleep && (isNaN(timeout) || timeout < 1)) return;
  if (enableAutoClose && (isNaN(autoCloseTimeout) || autoCloseTimeout < 1)) return;
  if (enableKeepActive && (isNaN(activeTabsToKeep) || activeTabsToKeep < 1)) return;

  chrome.storage.local.set({
    timeout: timeout,
    autoCloseTimeout: autoCloseTimeout,
    activeTabsToKeep: activeTabsToKeep,
    excludeAudio: excludeAudio,
    whitelist: whitelist,
    enableAutoSleep,
    enableAutoClose,
    enableKeepActive,
    language
  }, () => {
    // 同步内存中的语言设置，使后续 i18n.getMessage() 立即生效
    i18n.setLanguage(language);
    if (!silent) {
      const status = document.getElementById('status');
      status.textContent = i18n.getMessage('statusSaved');
      setTimeout(() => {
        status.textContent = '';
      }, 2000);
    }
    // 同时更新主页面的显示
    updatePopup();
  });
}

// 加载设置
function restoreOptions() {
  chrome.storage.local.get({
    timeout: DEFAULT_TIMEOUT,
    autoCloseTimeout: DEFAULT_AUTO_CLOSE_TIMEOUT,
    activeTabsToKeep: DEFAULT_KEEP_ACTIVE,
    excludeAudio: DEFAULT_EXCLUDE_AUDIO,
    whitelist: DEFAULT_WHITELIST,
    language: DEFAULT_LANGUAGE,
    enableAutoSleep: null,
    enableAutoClose: null,
    enableKeepActive: null
  }, (items) => {
    const fields = [
      'timeout', 'autoCloseTimeout', 'activeTabsToKeep',
      'excludeAudio', 'whitelist',
      'enableAutoSleep', 'enableAutoClose', 'enableKeepActive'
    ];

    document.getElementById('timeout').value = items.timeout;
    let autoCloseTimeout = items.autoCloseTimeout;
    if (autoCloseTimeout === 0) autoCloseTimeout = DEFAULT_AUTO_CLOSE_TIMEOUT;
    document.getElementById('autoCloseTimeout').value = autoCloseTimeout;
    document.getElementById('activeTabsToKeep').value = items.activeTabsToKeep;
    document.getElementById('excludeAudio').checked = items.excludeAudio;
    document.getElementById('whitelist').value = items.whitelist;
    document.getElementById('language').value = items.language;

    const enableAutoSleep = items.enableAutoSleep !== null ? items.enableAutoSleep : true;
    const enableAutoClose = items.enableAutoClose !== null ? items.enableAutoClose : false;
    const enableKeepActive = items.enableKeepActive !== null ? items.enableKeepActive : (items.activeTabsToKeep > 0);

    document.getElementById('enableAutoSleep').checked = enableAutoSleep;
    document.getElementById('enableAutoClose').checked = enableAutoClose;
    document.getElementById('enableKeepActive').checked = enableKeepActive;

    // 根据开关状态显示/隐藏内容
    document.getElementById('timeout-content').classList.toggle('hidden', !enableAutoSleep);
    document.getElementById('autoClose-content').classList.toggle('hidden', !enableAutoClose);
    document.getElementById('keepActive-content').classList.toggle('hidden', !enableKeepActive);

    // 绑定实时保存逻辑
    const debouncedSave = debounce(() => saveOptions(true), 500);

    fields.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;

      const eventType = (el.type === 'checkbox') ? 'change' : 'input';
      el.addEventListener(eventType, () => {
        // 更新显示状态
        if (id === 'enableAutoSleep') document.getElementById('timeout-content').classList.toggle('hidden', !el.checked);
        if (id === 'enableAutoClose') document.getElementById('autoClose-content').classList.toggle('hidden', !el.checked);
        if (id === 'enableKeepActive') document.getElementById('keepActive-content').classList.toggle('hidden', !el.checked);

        debouncedSave();
      });
    });

    // 语言切换：立即重新翻译 UI + 更新主面板，并持久化（background 监听 storage 变化刷新分组标题）
    const languageSelect = document.getElementById('language');
    languageSelect.addEventListener('change', () => {
      const lang = languageSelect.value;
      i18n.setLanguage(lang);
      translatePage();
      updatePopup();
      chrome.storage.local.set({ language: lang });
    });
  });
}

function formatTime(ms, isCountdown = false) {
  if (ms < 0) ms = 0;
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  
  const minStr = i18n.getMessage('minutes') || 'm';
  const secStr = i18n.getMessage('seconds') || 's';
  const afterSleepStr = isCountdown ? (i18n.getMessage('afterSleep') || ' to nap') : '';
  
  if (minutes >= 1) {
    return `${minutes}${minStr}${afterSleepStr}`;
  }
  return `${seconds}${secStr}${afterSleepStr}`;
}

// Tooltip logic
function showTooltip(e, text) {
  const tooltip = document.getElementById('tooltip');
  if (!tooltip) return;
  
  tooltip.textContent = text;
  
  // Reset styles to get accurate measurements
  tooltip.style.display = 'block';
  tooltip.style.visibility = 'hidden';
  tooltip.classList.remove('visible');
  
  const rect = e.currentTarget.getBoundingClientRect();
  const tooltipWidth = tooltip.offsetWidth;
  const tooltipHeight = tooltip.offsetHeight;
  
  // Position above the button, centered
  let top = rect.top - tooltipHeight - 8;
  let left = rect.left + (rect.width / 2) - (tooltipWidth / 2);
  
  // Boundary checks
  if (top < 0) top = rect.bottom + 8;
  if (left < 4) left = 4;
  if (left + tooltipWidth > window.innerWidth - 4) {
    left = window.innerWidth - tooltipWidth - 4;
  }
  
  tooltip.style.top = `${top}px`;
  tooltip.style.left = `${left}px`;
  tooltip.style.visibility = 'visible';
  tooltip.classList.add('visible');
}

function hideTooltip() {
  const tooltip = document.getElementById('tooltip');
  if (tooltip) {
    tooltip.classList.remove('visible');
  }
}

async function toggleWhitelist(tab, isWhitelisted) {
  const settings = await storageGet({ whitelist: DEFAULT_WHITELIST }, 'toggleWhitelist.storageGet');
  let whitelist = settings.whitelist.split('\n').map(s => s.trim()).filter(s => s.length > 0);
  
  let domain = '';
  try {
    const url = new URL(tab.url);
    domain = url.hostname;
    if (!domain && tab.url.startsWith('chrome://')) {
      domain = tab.url.split('/')[2];
    }
  } catch (e) {
    domain = tab.url;
  }

  if (!domain) return;

  let addedToWhitelist = false;
  if (isWhitelisted) {
    // 移除
    whitelist = whitelist.filter(item => item !== domain && !tab.url.includes(item));
  } else {
    // 添加
    if (!whitelist.includes(domain)) {
      whitelist.push(domain);
      addedToWhitelist = true;
    }
  }
  
  await storageSet({ whitelist: whitelist.join('\n') }, 'toggleWhitelist.storageSet');
  
  if (addedToWhitelist) {
    // 发送消息通知 background 唤醒符合新白名单的标签页
    chrome.runtime.sendMessage({ action: 'wakeUpByWhitelist' });
  }

  updatePopup();
}

async function reloadAllTabs() {
  const reloadButton = document.getElementById('reload-all-tabs');
  if (reloadButton?.disabled) return;

  hideTooltip();
  if (reloadButton) {
    reloadButton.disabled = true;
    reloadButton.style.opacity = '0.45';
    reloadButton.style.cursor = 'default';
  }

  await safeUpdate(async () => {
    const tabs = await chrome.tabs.query({});
    const reloads = tabs
      .filter(tab => typeof tab.id === 'number')
      .map(tab => chrome.tabs.reload(tab.id).catch(error => {
        console.warn(`Failed to reload tab ${tab.id}:`, error);
      }));

    await Promise.all(reloads);
  });

  if (reloadButton) {
    reloadButton.disabled = false;
    reloadButton.style.opacity = '';
    reloadButton.style.cursor = '';
  }
}

// 获取安全的 Favicon URL
function getFaviconUrl(tab) {
  // 如果是本地开发环境的 HTTP 图标，为了避免 Mixed Content 错误，
  // 我们在插件弹窗（HTTPS 环境）中强制使用 Chrome 的 favicon 服务来代理
  if (tab.favIconUrl && 
      !tab.favIconUrl.startsWith('chrome-extension://') && 
      tab.favIconUrl.startsWith('https://')) {
    return tab.favIconUrl;
  }
  
  if (!tab.url) return null;
  
  try {
    // 使用 Chrome 的 favicon 服务，这会通过浏览器底层处理图标获取，
    // 能够安全地在扩展页面显示，并解决跨域和 Mixed Content 问题。
    const url = new URL(`chrome-extension://${chrome.runtime.id}/_favicon/`);
    url.searchParams.set('pageUrl', tab.url);
    url.searchParams.set('size', '32');
    return url.toString();
  } catch (e) {
    return null;
  }
}

function createTabItem(tab, settings, currentWindow, now, whitelist, timeoutMs, enableAutoSleep) {
  const isNapped = tab.discarded;
  const isWhitelisted = whitelist.some(pattern => tab.url.includes(pattern) || tab.title.includes(pattern));
  const isCurrentViewing = tab.active && tab.windowId === currentWindow.id;
  
  const tabItem = document.createElement('div');
  tabItem.className = 'tab-item';
  tabItem.dataset.tabId = tab.id;
  
  // Favicon container
  const faviconContainer = document.createElement('div');
  faviconContainer.className = 'tab-favicon';
  
  const safeFaviconUrl = getFaviconUrl(tab);
  if (safeFaviconUrl) {
    const img = document.createElement('img');
    img.src = safeFaviconUrl;
    img.onerror = () => {
      if (img.src !== safeFaviconUrl) return;
      img.style.display = 'none';
      const letter = document.createElement('span');
      letter.textContent = tab.title ? tab.title.charAt(0).toUpperCase() : '?';
      letter.style.fontSize = '10px';
      letter.style.fontWeight = 'bold';
      letter.style.color = 'var(--text-secondary)';
      faviconContainer.appendChild(letter);
    };
    faviconContainer.appendChild(img);
  } else {
    const letter = document.createElement('span');
    letter.textContent = tab.title ? tab.title.charAt(0).toUpperCase() : '?';
    letter.style.fontSize = '10px';
    letter.style.fontWeight = 'bold';
    letter.style.color = 'var(--text-secondary)';
    faviconContainer.appendChild(letter);
  }
  tabItem.appendChild(faviconContainer);

  const info = document.createElement('div');
  info.className = 'tab-info';
  
  const title = document.createElement('div');
  title.className = 'tab-title';
  title.textContent = tab.title;
  title.title = tab.title;

  // 悬停时修改标题文字的逻辑
  if (isCurrentViewing || isWhitelisted) {
    const originalTitle = tab.title;
    const hoverText = isCurrentViewing
      ? (i18n.getMessage('currentTabHover') || 'Current Tab')
      : (i18n.getMessage('whitelistedTabHover') || 'Whitelisted Tab');
    
    tabItem.addEventListener('mouseenter', () => {
      title.textContent = hoverText;
      title.classList.add('hover-info');
    });
    tabItem.addEventListener('mouseleave', () => {
      title.textContent = originalTitle;
      title.classList.remove('hover-info');
    });
  }
  
  const meta = document.createElement('div');
  meta.className = 'tab-meta';
  
  const timeSpan = document.createElement('span');
  timeSpan.className = 'tab-time';
  timeSpan.dataset.tabId = tab.id;
  timeSpan.dataset.lastAccessed = tab.lastAccessed || 0;
  timeSpan.dataset.isNapped = isNapped;
  timeSpan.dataset.isCurrentViewing = isCurrentViewing;
  timeSpan.dataset.isWhitelisted = isWhitelisted;
  
  updateTimeSpan(timeSpan, settings, now, timeoutMs, enableAutoSleep);
  
  const actions = document.createElement('div');
  actions.className = 'tab-actions';

  if (!isNapped && !tab.pinned) {
    const napBtn = document.createElement('button');
    napBtn.className = 'action-btn nap-btn';
    napBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path><line x1="12" y1="2" x2="12" y2="12"></line></svg>';
    const napTitle = i18n.getMessage('napSingleTab') || 'Nap';
    napBtn.onmouseenter = (e) => showTooltip(e, napTitle);
    napBtn.onmouseleave = hideTooltip;
    napBtn.onclick = async (e) => {
      e.stopPropagation();
      hideTooltip();
      await safeUpdate(async () => {
        await chrome.runtime.sendMessage({ action: 'napSingleTab', tabId: tab.id });
        updatePopup();
      });
    };
    actions.appendChild(napBtn);
  }

  const wlBtn = document.createElement('button');
  wlBtn.className = `whitelist-btn ${isWhitelisted ? 'active' : ''}`;
  wlBtn.innerHTML = isWhitelisted 
    ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>'
    : '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20v-8m0 0V4m0 8h8m-8 0H4"></path></svg>';
  
  const wlTitle = isWhitelisted
    ? i18n.getMessage('removeFromWhitelist')
    : i18n.getMessage('addToWhitelist');
  
  wlBtn.onmouseenter = (e) => showTooltip(e, wlTitle);
  wlBtn.onmouseleave = hideTooltip;
  
  wlBtn.onclick = async (e) => {
    e.stopPropagation();
    hideTooltip();
    await safeUpdate(async () => {
      toggleWhitelist(tab, isWhitelisted);
    });
  };
  actions.appendChild(wlBtn);

  // Add close button
  const closeBtn = document.createElement('button');
  closeBtn.className = 'action-btn close-btn';
  closeBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
  const closeTitle = i18n.getMessage('closeTab') || 'Close Tab';
  closeBtn.onmouseenter = (e) => showTooltip(e, closeTitle);
  closeBtn.onmouseleave = hideTooltip;
  closeBtn.onclick = async (e) => {
    e.stopPropagation();
    hideTooltip();
    await chrome.tabs.remove(tab.id);
    updatePopup();
  };
  actions.appendChild(closeBtn);

  meta.appendChild(timeSpan);
  info.appendChild(title);
  info.appendChild(meta);
  tabItem.appendChild(info);
  tabItem.appendChild(actions);
  
  tabItem.onclick = () => {
    chrome.tabs.update(tab.id, { active: true });
    chrome.windows.update(tab.windowId, { focused: true });
  };

  return tabItem;
}

function updateTimeSpan(timeSpan, settings, now, timeoutMs, enableAutoSleep) {
  const isNapped = timeSpan.dataset.isNapped === 'true';
  const isCurrentViewing = timeSpan.dataset.isCurrentViewing === 'true';
  const isWhitelisted = timeSpan.dataset.isWhitelisted === 'true';
  const tabId = parseInt(timeSpan.dataset.tabId);
  const tabItem = timeSpan.closest('.tab-item');
  
  timeSpan.classList.remove('napped', 'active', 'countdown');
  timeSpan.style.color = '';
  timeSpan.textContent = '';
  if (tabItem) tabItem.classList.remove('has-timer');

  const autoCloseTimeoutMs = (settings.autoCloseTimeout || 0) * 60 * 1000;
  const enableAutoClose = settings.enableAutoClose ?? false;

  if (isNapped) {
    timeSpan.classList.add('napped');
    const nappedAt = settings.nappedTabsData[tabId]?.nappedAt;
    
    let timeText = '';
    if (nappedAt) {
      timeText = formatTime(now - nappedAt);
    }

    // Add close countdown if enabled
    if (enableAutoClose && autoCloseTimeoutMs > 0) {
      const awakenedAt = settings.awakenedTabsData[tabId]?.awakenedAt || 0;
      const lastActive = Math.max(parseFloat(timeSpan.dataset.lastAccessed) || 0, awakenedAt);
      const remainingClose = autoCloseTimeoutMs - (now - lastActive);
      
      if (remainingClose > 0) {
        const closeStr = i18n.getMessage('autoCloseIn') || ' to close';
        const closeTime = formatTime(remainingClose);
        const nappedForStr = i18n.getMessage('nappedFor') || 'Napped';
        if (timeText) {
          timeSpan.textContent = `${nappedForStr} ${timeText} (${closeTime}${closeStr})`;
        } else {
          timeSpan.textContent = `${closeTime}${closeStr}`;
        }
        if (tabItem) tabItem.classList.add('has-timer');
      } else {
        timeSpan.textContent = timeText;
        if (timeText && tabItem) tabItem.classList.add('has-timer');
      }
    } else {
      timeSpan.textContent = timeText;
      if (timeText && tabItem) tabItem.classList.add('has-timer');
    }
  } else if (isCurrentViewing) {
    timeSpan.classList.add('active');
  } else if (isWhitelisted) {
    timeSpan.style.color = 'var(--text-secondary)';
  } else {
    if (!enableAutoSleep) {
      // 禁用自动休眠时不显示倒计时
      return;
    }
    const awakenedAt = settings.awakenedTabsData[tabId]?.awakenedAt || 0;
    const lastActive = Math.max(parseFloat(timeSpan.dataset.lastAccessed) || 0, awakenedAt);
    const remaining = timeoutMs - (now - lastActive);
    
    if (remaining > 0) {
      timeSpan.textContent = formatTime(remaining, true);
      timeSpan.classList.add('countdown');
      if (tabItem) tabItem.classList.add('has-timer');
    }
  }
}

async function safeUpdate(fn) {
  if (popupDisposed) return;
  try {
    // 检查扩展上下文是否有效
    if (!chrome.runtime?.id) {
      stopPopupUpdates();
      return;
    }
    await fn();
  } catch (e) {
    if (isExpectedContextError(e)) {
      stopPopupUpdates();
    } else {
      console.error('[TabNap:popup] Update error:', e);
    }
  }
}

async function updateTimersOnly() {
  if (popupDisposed) return;
  await safeUpdate(async () => {
    if (popupDisposed) return;
    const settings = await storageGet({ 
      timeout: DEFAULT_TIMEOUT,
      autoCloseTimeout: DEFAULT_AUTO_CLOSE_TIMEOUT,
      nappedTabsData: {},
      awakenedTabsData: {},
      enableAutoSleep: null,
      enableAutoClose: null
    }, 'updateTimersOnly.storageGet');
    const timeoutMs = settings.timeout * 60 * 1000;
    const now = Date.now();
    const enableAutoSleep = settings.enableAutoSleep !== null ? settings.enableAutoSleep : true;
    
    const timeSpans = document.querySelectorAll('.tab-time');
    timeSpans.forEach(span => {
      updateTimeSpan(span, settings, now, timeoutMs, enableAutoSleep);
    });
  });
}

function postPopupSize() {
  if (window.parent === window) return;
  const height = Math.ceil(document.documentElement.scrollHeight);
  window.parent.postMessage({ type: 'tabNapResize', height }, '*');
}

function requestTabsFromHost() {
  if (window.parent === window) return Promise.resolve(null);

  return new Promise(resolve => {
    const requestId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const timeoutId = setTimeout(() => {
      window.removeEventListener('message', handleMessage);
      resolve(null);
    }, 1000);

    function handleMessage(event) {
      if (event.source !== window.parent) return;
      if (event.data?.type !== 'tabNapTabsResponse') return;
      if (event.data.requestId !== requestId) return;

      clearTimeout(timeoutId);
      window.removeEventListener('message', handleMessage);
      resolve(event.data.response || null);
    }

    window.addEventListener('message', handleMessage);
    window.parent.postMessage({ type: 'tabNapRequestTabs', requestId }, '*');
  });
}

async function getPopupWindowTabs() {
  const response = await requestTabsFromHost()
    || await chrome.runtime.sendMessage({ action: 'getPopupTabs' }).catch(() => null);

  if (Array.isArray(response?.tabs)) {
    return {
      tabs: response.tabs,
      currentWindow: { id: response.windowId }
    };
  }

  debugWarn('Falling back to direct chrome.tabs.query({}).');
  return {
    tabs: await chrome.tabs.query({}),
    currentWindow: { id: null }
  };
}

function createEmptyState(message) {
  const emptyState = document.createElement('div');
  emptyState.style.textAlign = 'center';
  emptyState.style.padding = '20px';
  emptyState.style.color = 'var(--text-secondary)';

  const title = document.createElement('div');
  title.textContent = message;
  emptyState.appendChild(title);

  return emptyState;
}

async function updatePopup() {
  if (popupDisposed) return;
  await safeUpdate(async () => {
    const settings = await storageGet({
      timeout: DEFAULT_TIMEOUT,
      autoCloseTimeout: DEFAULT_AUTO_CLOSE_TIMEOUT,
      nappedTabsData: {},
      awakenedTabsData: {},
      whitelist: DEFAULT_WHITELIST,
      enableAutoSleep: null,
      enableAutoClose: null
    }, 'updatePopup.storageGet');
    
    const timeoutMs = settings.timeout * 60 * 1000;
    const enableAutoSleep = settings.enableAutoSleep !== null ? settings.enableAutoSleep : true;

    const whitelist = settings.whitelist.split('\n').map(s => s.trim()).filter(s => s.length > 0);
    
    const { tabs: allTabs, currentWindow } = await getPopupWindowTabs();
    
    const tabListContainer = document.getElementById('tab-list');
    const searchInput = document.getElementById('tab-search');
    const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const now = Date.now();

    // 预先分类和过滤
    const nappedTabs = allTabs.filter(t => t.discarded && !t.pinned);
    const activeTabs = allTabs.filter(t => !t.discarded && !t.pinned);

    // 更新标签栏标题和数量
    const nappedLabel = i18n.getMessage('tabNapped') || 'Hibernated';
    const activeLabel = i18n.getMessage('tabActive') || 'Running';
    document.getElementById('tab-napped').textContent = `${nappedLabel} (${nappedTabs.length})`;
    document.getElementById('tab-active').textContent = `${activeLabel} (${activeTabs.length})`;

    // 决定显示哪些标签页
    let displayTabs = currentTabType === 'active' ? activeTabs : nappedTabs;

    // 搜索过滤
    if (searchTerm) {
      // 隐藏 tab switcher 当搜索时
      const switcher = document.querySelector('.tab-switcher');
      if (switcher) switcher.classList.add('hidden');

      displayTabs = allTabs.filter(t => {
        const title = (t.title || '').toLowerCase();
        const url = (t.url || '').toLowerCase();
        return title.includes(searchTerm) || url.includes(searchTerm);
      });
    } else {
      // 无搜索词，恢复默认显示
      const switcher = document.querySelector('.tab-switcher');
      if (switcher) switcher.classList.remove('hidden');
    }
    
    // 排序：按最后访问时间降序（最近访问的在前）
    displayTabs.sort((a, b) => {
      const aTime = a.lastAccessed || 0;
      const bTime = b.lastAccessed || 0;
      return bTime - aTime;
    });

    tabListContainer.innerHTML = '';
    if (displayTabs.length === 0 && searchTerm) {
        tabListContainer.appendChild(createEmptyState('No tabs found'));
    } else if (displayTabs.length === 0) {
        const emptyMessage = currentTabType === 'active'
          ? 'No running tabs found'
          : 'No napped tabs yet';
        tabListContainer.appendChild(createEmptyState(emptyMessage));
    } else {
        const fragment = document.createDocumentFragment();
        for (const tab of displayTabs) {
          fragment.appendChild(createTabItem(tab, settings, currentWindow, now, whitelist, timeoutMs, enableAutoSleep));
        }
        tabListContainer.appendChild(fragment);
    }
    postPopupSize();
  });
}

document.getElementById('open-settings').addEventListener('click', showSettingsView);
document.getElementById('reload-all-tabs').addEventListener('click', reloadAllTabs);
document.getElementById('back-to-main').addEventListener('click', showMainView);
document.getElementById('close-popup').addEventListener('click', () => {
    if (window.parent !== window) {
      window.parent.postMessage('closeTabNapPanel', '*');
    } else {
      window.close();
    }
  });

  let searchTimeout;
  document.getElementById('tab-search').addEventListener('input', () => {
    if (searchTimeout) clearTimeout(searchTimeout);
    searchTimeout = setTimeout(updatePopup, 150);
  });

document.getElementById('tab-active').addEventListener('click', () => {
  currentTabType = 'active';
  document.getElementById('tab-active').classList.add('active');
  document.getElementById('tab-napped').classList.remove('active');
  updatePopup();
});

document.getElementById('tab-napped').addEventListener('click', () => {
  currentTabType = 'napped';
  document.getElementById('tab-napped').classList.add('active');
  document.getElementById('tab-active').classList.remove('active');
  updatePopup();
});

document.addEventListener('DOMContentLoaded', async () => {
  if (popupDisposed) return;
  if (window.parent !== window) {
    document.body.classList.add('is-iframe');
  }
  // 先加载持久化的语言设置，再翻译，确保首次渲染即使用正确语言
  await i18n.loadLanguage();
  await safeUpdate(async () => {
    translatePage();
    updatePopup();
  });

  // 监听标签页和分组的变化，实时更新界面
  const debouncedUpdate = debounce(updatePopup, 300);
  chrome.tabs.onUpdated.addListener(debouncedUpdate);
  chrome.tabs.onRemoved.addListener(debouncedUpdate);
  chrome.tabs.onActivated.addListener(debouncedUpdate);
  chrome.tabGroups.onUpdated.addListener(debouncedUpdate);
  chrome.tabGroups.onRemoved.addListener(debouncedUpdate);
  chrome.tabs.onDetached.addListener(debouncedUpdate);
  chrome.tabs.onAttached.addListener(debouncedUpdate);
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && (changes.nappedTabsData || changes.awakenedTabsData || changes.whitelist)) {
      debouncedUpdate();
    }
  });
  
  // 每秒更新一次计时器，而不是重建整个列表
  updateInterval = setInterval(updateTimersOnly, 1000);
});

function cleanupPopup() {
  stopPopupUpdates();
}

// 当弹窗关闭时清除定时器。使用 pagehide（unload 的现代替代），
// 在 MV3 弹窗、iframe、bfcache 等场景下都能可靠触发，且不会触发
// "unload is not allowed" 的 Permissions Policy 警告。
window.addEventListener('pagehide', cleanupPopup);
